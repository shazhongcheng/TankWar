package com.xiaosha.TankWar;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.ImageObserver;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.ImageIcon;

/**
 * 
 * ����̹����
 *
 */
public class Tank {
//	int reTankCount = Integer.parseInt(PropertyMgr.getProperty("reTankCount"));

	private boolean robot = false;
	
    public boolean isRobot() {
		return robot;
	}
	public void setRobot(boolean robot) {
		this.robot = robot;
	}

	//	̹�˵�λ��
	private int x,y;
	
	private int oldX, oldY;
    
//	̹�˵��ٶ�
	public static final int XSPEED = 5;
	public static final int YSPEED = 5;
	
	public static final int LIFE = 100;
//	�õ�������Ķ���
	static TankClient tc;
//	���ֵ���
	private boolean good;
	
	private BloodBar bb = new BloodBar();
	
	private int life = 100;
	
	public int getLife() {
		return life;
	}
	public void setLife(int life) {
		this.life = life;
	}
	public boolean isGood() {
		return good;
	}
	public void setGood(boolean good) {
		this.good = good;
	}

	private static Random r = new Random();
	
	private boolean live = true;
	
    public boolean isLive() {
		return live;
	}
	public void setLive(boolean live) {
		this.live = live;
	}

//	����̹�˵���ʻ����
	private boolean bL = false, bU = false, bR = false, bD =false;
	private Direction dir = Direction.STOP;
	private Direction ptDir = Direction.D;
	
	private int step = r.nextInt(12)+3; 
	
	private static Map<String, Image> imgs = new HashMap<String, Image>();
	
	/**
	 * ��̬������
	 */
	static {
		imgs.put("L",new ImageIcon("./images/tankL.gif").getImage());
		imgs.put("LU",new ImageIcon("./images/tankLU.gif").getImage());
		imgs.put("U",new ImageIcon("./images/tankU.gif").getImage());
		imgs.put("RU",new ImageIcon("./images/tankRU.gif").getImage());
		imgs.put("R",new ImageIcon("./images/tankR.gif").getImage());
		imgs.put("RD",new ImageIcon("./images/tankRD.gif").getImage());
		imgs.put("D",new ImageIcon("./images/tankD.gif").getImage());
		imgs.put("LD",new ImageIcon("./images/tankLD.gif").getImage());
	}
	
//	̹�˵Ĵ�С
	public static final int WIDTH = 30;
	public static final int HEIGHT = 30;
	
//	Tank�Ĺ��캯��
	public Tank(int x, int y, boolean good) {
		this.x = x;
		this.y = y;
		this.good = good;
	}
	
//	��ʼ��tc
	public Tank(int x, int y, boolean good, TankClient tc){
		this(x,y,good);
		Tank.tc = tc;
	}
	
	
//	��ʼ������̹��
public Tank(int x, int y, boolean good, Direction dir,boolean robot, TankClient tc) {
	this(x, y, good, tc);
	this.robot = robot;
	this.dir = dir;
}
//	 ���û滭����
	public void draw(Graphics g2){
		if(!live){
			if(!good){
				tc.tanks.remove(this);
			}
			if(good){
				tc.tanks.remove(this);
			}
			return;
		}
		
		if(good && !robot){
			bb.draw(g2);
		}
			
//			���ڹ�
			switch(ptDir){
			case L:
				g2.drawImage(imgs.get("L"), x,  y, null);
				break;
			case LU:
				g2.drawImage(imgs.get("LU"), x,  y, null);			
				break;
			case U:
				g2.drawImage(imgs.get("U"), x,  y, null);			
				break;
			case RU:
				g2.drawImage(imgs.get("RU"), x,  y, null);			
				break;
			case R:
				g2.drawImage(imgs.get("R"), x,  y, null);			
				break;
			case RD:
				g2.drawImage(imgs.get("RD"), x,  y, null);			
				break;
			case D:
				g2.drawImage(imgs.get("D"), x,  y, null);		
				break;
			case LD:
				g2.drawImage(imgs.get("LD"), x,  y, null);		
				break;
			default:
				break;
			}
			move();
	}
	
	
//	̹���˶�
	void move(){
		
		this.oldX = x;
		this.oldY = y;
		
		switch(dir){
		case L:
			x -= XSPEED;
			break;
		case LU:
			x -= XSPEED;
			y -= YSPEED;
			break;
		case U:
			y -= YSPEED;
			break;
		case RU:
			x += XSPEED;
			y -= YSPEED;
			break;
		case R:
			x += XSPEED;
			break;
		case RD:
			x += XSPEED;
			y += YSPEED;
			break;
		case D:
			y += YSPEED;
			break;
		case LD:
			x -= XSPEED;
			y += YSPEED;
			break;
		case STOP:
			break;
		}
		
		if(this.dir != Direction.STOP){
			this.ptDir = this.dir;
		}
//		����̹����ʻ�߽�
		if(x < 0) x = 0;
		if(y < 30) y = 30;
		if(x + Tank.WIDTH > TankClient.GAME_WIDTH) x = TankClient.GAME_WIDTH - Tank.WIDTH;
		if(y + Tank.HEIGHT > TankClient.GAME_HEIGHT) y = TankClient.GAME_HEIGHT - Tank.HEIGHT;
		
		if(robot){
			Direction[] dirs = Direction.values();
			if(step==0){
				step = r.nextInt(12)+3;
				int rn = r.nextInt(dirs.length);
				this.dir = dirs[rn];
			}
			step--;
			
			if(r.nextInt(40)>35){
				this.fire();
			}
		}
	}
	
	private void stay(){
		x = oldX;
		y = oldY;
	}
	
//	���̰��¼���
	public void keyPressed(KeyEvent e){

//		��ü��̰�����������
		int key = e.getKeyCode();
//		�ı�̹�˵��˶�״̬	
		switch(key){
		case KeyEvent.VK_LEFT :
			bL = true;
			break;
		case KeyEvent.VK_UP :
			bU = true;
			break;
		case KeyEvent.VK_RIGHT :
			bR = true;
			break;
		case KeyEvent.VK_DOWN :
			bD = true;
			break;
		}
		locateDirection();
	}
	
//	�趨�˸�����
	void locateDirection(){
		if(bL && !bU && !bR && !bD) dir = Direction.L;	
		else if(bL && bU && !bR && !bD) dir = Direction.LU;
		else if(!bL && bU && !bR && !bD) dir = Direction.U;
		else if(!bL && bU && bR && !bD) dir = Direction.RU;
		else if(!bL && !bU && bR && !bD) dir = Direction.R;
		else if(!bL && !bU && bR && bD) dir = Direction.RD;
		else if(!bL && !bU && !bR && bD) dir = Direction.D;
		else if(bL && !bU && !bR && bD) dir = Direction.LD;
		else if(!bL && !bU && !bR && !bD) dir = Direction.STOP;
	}

//	����̧�����
	public void keyReleased(KeyEvent e) {
//		��ü��̰�����������
		int key = e.getKeyCode();
		int reTankCount = 4;
//		�ı�̹�˵��˶�״̬	
		switch(key){
		case KeyEvent.VK_F2:
			newTanks(reTankCount,false);
			break;
		case KeyEvent.VK_F3:
			this.live = true;
			this.life = LIFE;
			break;
		case KeyEvent.VK_F4:
			newTanks(reTankCount,true);
			break;
		case KeyEvent.VK_SPACE:
			fire();
			break;
		case KeyEvent.VK_LEFT :
			bL = false;
			break;
		case KeyEvent.VK_UP :
			bU = false;
			break;
		case KeyEvent.VK_RIGHT :
			bR = false;
			break;
		case KeyEvent.VK_DOWN :
			bD = false;
			break;
		case KeyEvent.VK_A:
			superFire();
			break;
		}
		locateDirection();
	}
	
//	����ӵ�
	public Missile fire(){
		if(!live) return null;
		int x = this.x + Tank.WIDTH/2 - Missile.WIDTH/2;
		int y = this.y + Tank.HEIGHT/2 - Missile.HEIGHT/2;
		Missile m = new Missile(x, y,good, ptDir, tc);
		tc.missiles.add(m);
		return m;
	}
	
	public Missile fire(Direction dir){
		if(!live) return null;
		int x = this.x + Tank.WIDTH/2 - Missile.WIDTH/2;
		int y = this.y + Tank.HEIGHT/2 - Missile.HEIGHT/2;
		Missile m = new Missile(x, y,good, dir, tc);
		tc.missiles.add(m);
		return m;
	}
	
//	��ײ������
	public Rectangle getRect(){
		return new Rectangle(x, y, WIDTH, HEIGHT);
	}
	
	public boolean collidesWithWall(Wall w){
		if(this.live && this.getRect().intersects(w.getRect())){
			this.stay();
			return true;
		}
		return false;
	}
	
	public boolean collidesWithTank(Tank t){
		if(this.live && t.isLive() && this.getRect().intersects(t.getRect())){
			this.stay();
			t.stay();
			return true;
		}
       return false;
	}
	
	public boolean collidesWithTanks(List<Tank> tanks){
		for(int i=0; i<tanks.size();i++){
			Tank t = tanks.get(i);
			if(this != t){
				if(collidesWithTank(t)){
					return true;
				}
			}
		}
		return false;
	}
	
	public static void newTanks(int tankCount,boolean camp){
		int number=0;
		Direction[] dirs = Direction.values();
		while(number!=tankCount){
			int rn = r.nextInt(dirs.length);
			int w = TankClient.GAME_WIDTH;
			int h = TankClient.GAME_HEIGHT;
			int x1 = r.nextInt(w-100)+50;
			int y1 = r.nextInt(h-100)+50;
			Direction dir = dirs[rn];
			Tank t = new Tank(x1, y1, camp ,dir,true ,tc);
			if(!t.collidesWithTanks(tc.tanks) && !t.collidesWithWall(tc.w1) && !t.collidesWithWall(tc.w2)){
				tc.tanks.add(t);
				number++;
			}
		}
	}
	
	private void superFire(){
		Direction[] dirs = Direction.values();
		for(int i=0; i<8 ;i++){
			fire(dirs[i]);
		}
	}
	
	private class BloodBar{
		public void draw(Graphics graphics ){
			Color color = graphics .getColor();
			graphics.setColor(Color.RED);
			graphics.drawRect(x, y-10, WIDTH, 10);
			int w = WIDTH * life/100;
			graphics.fillRect(x, y-10, w, 10);
			graphics.setColor(color);
		}
	}
	
	public boolean eat(Blood b){
		if(this.live && b.isLive() && this.getRect().intersects(b.getRect())){
			this.life = LIFE;
			b.setLive(false);
			return true;
		}
		return false;
	}
	public void beHit() {
		if(good && !robot){
			life-=20;
			if(life <=0 ){
				live = false;
			}
		}else{
			live = false;
		}
	}
}
