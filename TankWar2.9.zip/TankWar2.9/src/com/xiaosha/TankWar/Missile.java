package com.xiaosha.TankWar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
/**
 * �����ӵ���
 */
public class Missile {
	/**
	 * �ӵ��ٶȵĳ���
	 */
	public static final int XSPEED = 10;
	public static final int YSPEED = 10;
	/**
	 * �ӵ���С�ĳ���
	 */
	public static final int WIDTH = 10;
	public static final int HEIGHT = 10;
	/**
	 * �ӵ���λ�úͷ���
	 */
	int x,y;
	Direction dir;
	/**
	 * �ӵ������ߵ���Ӫ
	 */
	private boolean good; 
	/**
	 * �ӵ���״̬
	 */
	private boolean live = true;
	
	private TankClient tc;
	/**
	 * 
	 * @return  �ӵ�״̬�ķ���
	 */
	public boolean isLive() {
		return live; 
	}
	
	
	private static Map<String, Image> imgs = new HashMap<String, Image>();
	
	/**
	 * ��̬������
	 */
	static {
		imgs.put("L",new ImageIcon("./images/missileL.gif").getImage());
		imgs.put("LU",new ImageIcon("./images/missileLU.gif").getImage());
		imgs.put("U",new ImageIcon("./images/missileU.gif").getImage());
		imgs.put("RU",new ImageIcon("./images/missileRU.gif").getImage());
		imgs.put("R",new ImageIcon("./images/missileR.gif").getImage());
		imgs.put("RD",new ImageIcon("./images/missileRD.gif").getImage());
		imgs.put("D",new ImageIcon("./images/missileD.gif").getImage());
		imgs.put("LD",new ImageIcon("./images/missileLD.gif").getImage());
	}
	
	
	
	/**
	 * 
	 * @param x �ӵ���x��λ��
	 * @param y �ӵ���y��λ��
	 * @param dir �ӵ��ķ���
	 */
	public Missile(int x, int y, Direction dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
	}
	/**
	 * 
	 * @param x �ӵ���x��λ��
	 * @param y �ӵ���y��λ��
	 * @param good �ӵ�����Ӫ
	 * @param dir �ӵ��ķ���
	 * @param tc
	 */
	public Missile(int x, int y, boolean good,Direction dir, TankClient tc) {
		this.x = x;
		this.y = y;
		this.good = good;
		this.dir = dir;
		this.tc = tc;
	}
	/**
	 * ���ӵ�
	 * @param g
	 */
	public void draw (Graphics g2){
//		
		/**
		 * ����ӵ��Ƿ�Ӧ�ò�ȥ
		 */
		if(!live){
			tc.missiles.remove(this);
			return;
		}
		/**
		 * ���ӵ�
		 */
		switch(dir){
		case L:
			g2.drawImage(imgs.get("L"), x,  y, null);
			break;
		case LU:
			g2.drawImage(imgs.get("LU"), x,  y, null);			
			break;
		case U:
			g2.drawImage(imgs.get("U"), x,  y, null);		
			break;
		case RU:
			g2.drawImage(imgs.get("RU"), x,  y, null);		
			break;
		case R:
			g2.drawImage(imgs.get("R"), x,  y, null);		
			break;
		case RD:
			g2.drawImage(imgs.get("RD"), x,  y, null);		
			break;
		case D:
			g2.drawImage(imgs.get("D"), x,  y, null);		
			break;
		case LD:
			g2.drawImage(imgs.get("LD"), x,  y, null);		
			break;
		default:
			break;
		}
		/**
		 * �ӵ��ƶ�
		 */
		move();
	}
	/**
	 * �ӵ����ƶ�����
	 */
	private void move() {
		switch(dir){
		case L:
			x -= XSPEED;
			break;
		case LU:
			x -= XSPEED;
			y -= YSPEED;
			break;
		case U:
			y -= YSPEED;
			break;
		case RU:
			x += XSPEED;
			y -= YSPEED;
			break;
		case R:
			x += XSPEED;
			break;
		case RD:
			x += XSPEED;
			y += YSPEED;
			break;
		case D:
			y += YSPEED;
			break;
		case LD:
			x -= XSPEED;
			y += YSPEED;
			break;
		default:
			break;
		}
		/**
		 * �ӵ������߽�ļ��
		 */
		if(x < 0 || y < 0 || x > TankClient.GAME_WIDTH || y > TankClient.GAME_HEIGHT){
			this.live = false;
		}
	}
//	��ײ������
	public Rectangle getRect(){
		return new Rectangle(x, y, WIDTH, HEIGHT);
	}
	
//	ײ���ж�
	public boolean hitTank (Tank t){
//		intersects���������ײ���
		if(this.live && this.getRect().intersects(t.getRect()) && t.isLive() && this.good != t.isGood()){
			t.beHit();
			this.live = false;
			Explode e = new Explode(x, y, tc);
			tc.explodes.add(e);
			return true;
		}
		return false; 
	}
	public boolean hitTanks(List<Tank> tanks){
		for(int i=0; i<tanks.size(); i++){
			if(hitTank(tanks.get(i))){
				return true;
			}
		}
		return false;
	}
	public boolean hitWall(Wall w){
		if(this.live && this.getRect().intersects(w.getRect())){
			this.live = false;
			return true;
		}
		return false;
	}
}
