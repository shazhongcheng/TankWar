package com.xiaosha.TankWar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;
/**
 * ����̹�˱�ըЧ����ʵ�ֵ���
 */
public class Explode {
	/**
	 * ��ը��λ��
	 */
	int x, y;
	/**
	 * ��ը��״̬
	 */
	private boolean live = true;
	
	static TankClient tc;
	
	
	/**
	 * ��ը�Ĵ�С
	 */
	private static Image[] images = {
			new ImageIcon("./images/0.gif").getImage(),
			new ImageIcon("./images/1.gif").getImage(),
			new ImageIcon("./images/2.gif").getImage(),
			new ImageIcon("./images/3.gif").getImage(),
			new ImageIcon("./images/4.gif").getImage(),
			new ImageIcon("./images/5.gif").getImage(),
			new ImageIcon("./images/6.gif").getImage(),
			new ImageIcon("./images/7.gif").getImage(),
			new ImageIcon("./images/8.gif").getImage(),
			new ImageIcon("./images/9.gif").getImage(),
			new ImageIcon("./images/10.gif").getImage()			 
	};
	
	int step = 0;
	
	private static boolean init = false;
	
//	��ʼ��tc
	public Explode(int x, int y, TankClient tc) {
		this.x = x;
		this.y = y;
		Explode.tc = tc;
	}



	public void draw(Graphics g2){
		
		if (!init) {
			for (int i = 0; i < images.length; i++) {
				g2.drawImage(images[i], -100, -100, null);
			}
			init = true;
		}
		
		/**
		 * ��ⱬը�Ƿ�Ӧ�ô���
		 */
		if(!live){
			tc.explodes.remove(this);
			return;
		}
		/**
		 * ��ⱬը�Ƿ����
		 */
		if(step == images.length){
			live = false;
			step = 0;
			return;
		} 
		/**
		 * ������ըЧ��
		 */
		g2.drawImage(images[step], x-step*2, y-step*2, null);
		
	    /**
		 * ��ը������һ��
		 */
	    step++;
	}
}
