package com.xiaosha.TankWar;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

public class Blood {
	int x, y, w, h;
	TankClient tc;
	
	private int step = 0;
	private int time = 0;

	Random random = new Random();
	
	private boolean  live = true;
	
	public boolean isLive() {
		return live;
	}

	public void setLive(boolean live) {
		this.live = live;
	}

	private int[][] pos={
			{450, 100},{260, 400},{575, 375},{100, 500},{260, 170},{365, 490},{540, 280}
	};
	
	public Blood(){
		x = pos[0][0];
		y = pos[0][1];
		w = h = 15;
	}
	
	public void draw(Graphics g){
		if(!live) return;
		
		Color c = g.getColor();
		g.setColor(Color.magenta);
		g.fillRect(x, y, w, h);
		g.setColor(c);
		
		
		if(time==0){
			time = random.nextInt(40)+30;
			move();
		}
		time--;
	}
	
	private void move(){
		step++;
		if(step == pos.length){
			step = 0;
		}
		x = pos[step][0];
		y = pos[step][1];
	}
	
	public Rectangle getRect() {
		return new Rectangle(x, y, w, h);
	}
}
