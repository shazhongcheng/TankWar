
public enum Dir {
	L, LU, U, RU, R, RD, D, LD, STOP
}
